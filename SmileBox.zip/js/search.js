$(document).ready( function () {
  $(".uk-search-input").hover(function () {
    $(".uk-seach").focus();
  })
})
